```html
<!-- Arquivo: backend/app/static/painel_convenios.html -->
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Faturamento - Convênios e Recibos</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Dados de exemplo (simulação)
        const guias = [
            { id: 1, numero: "TISS-2025-0001", paciente: "Maria Silva", operadora: "Unimed", data: "2025-03-01", valor: 250.00, status: "Emitida" },
            { id: 2, numero: "TISS-2025-0002", paciente: "João Santos", operadora: "Amil", data: "2025-03-02", valor: 180.50, status: "Emitida" },
            { id: 3, numero: "TISS-2025-0003", paciente: "Ana Costa", operadora: "Bradesco Saúde", data: "2025-03-03", valor: 320.00, status: "Emitida" },
            { id: 4, numero: "TISS-2025-0004", paciente: "Carlos Pereira", operadora: "Unimed", data: "2025-03-04", valor: 150.00, status: "Emitida" },
            { id: 5, numero: "TISS-2025-0005", paciente: "Fernanda Lima", operadora: "SulAmérica", data: "2025-03-05", valor: 410.00, status: "Emitida" },
            { id: 6, numero: "TISS-2025-0006", paciente: "Rafael Alves", operadora: "Amil", data: "2025-03-06", valor: 95.00, status: "Emitida" },
            { id: 7, numero: "TISS-2025-0007", paciente: "Juliana Rocha", operadora: "Unimed", data: "2025-03-07", valor: 275.00, status: "Emitida" },
            { id: 8, numero: "TISS-2025-0008", paciente: "Pedro Martins", operadora: "Bradesco Saúde", data: "2025-03-08", valor: 130.00, status: "Emitida" }
        ];

        // Resumo mensal (simulação)
        const resumoMensal = {
            mes: "Março/2025",
            totalParticular: 1250.00,
            totalConvenios: 1810.50,
            quantidadeParticular: 5,
            quantidadeConvenios: 8
        };

        let guiasFiltradas = [...guias];

        function renderTable(data) {
            const tbody = document.getElementById('tbody-guias');
            tbody.innerHTML = '';
            data.forEach(g => {
                const tr = document.createElement('tr');
                tr.className = 'border-b hover:bg-gray-50';
                tr.innerHTML = `
                    <td class="px-4 py-3 text-sm text-gray-800">${g.numero}</td>
                    <td class="px-4 py-3 text-sm text-gray-800">${g.paciente}</td>
                    <td class="px-4 py-3 text-sm text-gray-800">${g.operadora}</td>
                    <td class="px-4 py-3 text-sm text-gray-800">${new Date(g.data).toLocaleDateString('pt-BR')}</td>
                    <td class="px-4 py-3 text-sm text-gray-800">R$ ${g.valor.toFixed(2)}</td>
                    <td class="px-4 py-3 text-sm">
                        <span class="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">${g.status}</span>
                    </td>
                    <td class="px-4 py-3 text-sm">
                        <button onclick="abrirModalRecibo(${g.id})" class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-xs font-medium transition">
                            Emitir Recibo
                        </button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }

        function filtrarPorOperadora() {
            const select = document.getElementById('filtro-operadora');
            const operadora = select.value;
            if (operadora === '') {
                guiasFiltradas = [...guias];
            } else {
                guiasFiltradas = guias.filter(g => g.operadora === operadora);
            }
            renderTable(guiasFiltradas);
        }

        function abrirModalRecibo(id) {
            const guia = guias.find(g => g.id === id);
            if (!guia) return;
            document.getElementById('recibo-numero').textContent = guia.numero;
            document.getElementById('recibo-paciente').textContent = guia.paciente;
            document.getElementById('recibo-operadora').textContent = guia.operadora;
            document.getElementById('recibo-valor').textContent = `R$ ${guia.valor.toFixed(2)}`;
            document.getElementById('recibo-data').textContent = new Date(guia.data).toLocaleDateString('pt-BR');
            document.getElementById('modal-recibo').classList.remove('hidden');
        }

        function fecharModal() {
            document.getElementById('modal-recibo').classList.add('hidden');
        }

        function imprimirRecibo() {
            const conteudo = document.getElementById('recibo-conteudo').innerHTML;
            const janela = window.open('', '_blank', 'width=600,height=400');
            janela.document.write(`
                <html>
                <head><title>Recibo de Reembolso</title></head>
                <body>${conteudo}</body>
                </html>
            `);
            janela.document.close();
            janela.print();
        }

        function atualizarResumo() {
            document.getElementById('resumo-mes').textContent = resumoMensal.mes;
            document.getElementById('resumo-particular').textContent = `R$ ${resumoMensal.totalParticular.toFixed(2)}`;
            document.getElementById('resumo-convenios').textContent = `R$ ${resumoMensal.totalConvenios.toFixed(2)}`;
            document.getElementById('resumo-qtd-particular').textContent = `${resumoMensal.quantidadeParticular} atendimentos`;
            document.getElementById('resumo-qtd-convenios').textContent = `${resumoMensal.quantidadeConvenios} atendimentos`;
        }

        // Inicialização
        document.addEventListener('DOMContentLoaded', () => {
            renderTable(guias);
            atualizarResumo();
        });
    </script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <!-- Cabeçalho -->
        <header class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800">Painel de Faturamento</h1>
            <p class="text-gray-600 mt-1">Convênios (TISS ANS 4.01) e Recibos de Reembolso</p>
        </header>

        <!-- Resumo Financeiro Mensal -->
        <section class="mb-8">
            <h2 class="text-xl font-semibold text-gray-700 mb-4">Resumo Financeiro Mensal</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-white rounded-lg shadow p-6">
                    <p class="text-sm text-gray-500">Mês</p>
                    <p id="resumo-mes" class="text-2xl font-bold text-gray-800 mt-1">-</p>
                </div>
                <div class="bg-white rounded-lg shadow p-6 border-l-4 border-blue-500">
                    <p class="text-sm text-gray-500">Atendimentos Particulares</p>
                    <p id="resumo-particular" class="text-2xl font-bold text-blue-600 mt-1">-</p>
                    <p id="resumo-qtd-particular" class="text-sm text-gray-500 mt-1">-</p>
                </div>
                <div class="bg-white rounded-lg shadow p-6 border-l-4 border-green-500">
                    <p class="text-sm text-gray-500">Atendimentos Convênios</p>
                    <p id="resumo-convenios" class="text-2xl font-bold text-green-600 mt-1">-</p>
                    <p id="resumo-qtd-convenios" class="text-sm text-gray-500 mt-1">-</p>
                </div>
                <div class="bg-white rounded-lg shadow p-6 border-l-4 border-purple-500">
                    <p class="text-sm text-gray-500">Total Geral</p>
                    <p class="text-2xl font-bold text-purple-600 mt-1" id="resumo-total">-</p>
                </div>
            </div>
        </section>

        <!-- Filtros e Tabela -->
        <section class="bg-white rounded-lg shadow p-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                <h2 class="text-xl font-semibold text-gray-700">Guias TISS Emitidas</h2>
                <div class="mt-4 md:mt-0">
                    <label for="filtro-operadora" class="text-sm text-gray-600 mr-2">Operadora:</label>
                    <select id="filtro-operadora" onchange="filtrarPorOperadora()" class="border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Todas</option>
                        <option value="Unimed">Unimed</option>
                        <option value="Amil">Amil</option>
                        <option value="Bradesco Saúde">Bradesco Saúde</option>
                        <option value="SulAmérica">SulAmérica</option>
                    </select>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead>
                        <tr class="bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            <th class="px-4 py-3">Número da Guia</th>
                            <th class="px-4 py-3">Paciente</th>
                            <th class="px-4 py-3">Operadora</th>
                            <th class="px-4 py-3">Data de Emissão</th>
                            <th class="px-4 py-3">Valor</th>
                            <th class="px-4 py-3">Status</th>
                            <th class="px-4 py-3">Ações</th>
                        </tr>
                    </thead>
                    <tbody id="tbody-guias">
                        <!-- Linhas geradas via JavaScript -->
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <!-- Modal de Recibo -->
    <div id="modal-recibo" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Recibo de Reembolso</h3>
                <button onclick="fecharModal()" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <div id="recibo-conteudo" class="text-sm text-gray-700">
                <p><strong>Número da Guia:</strong> <span id="recibo-numero"></span></p>
                <p><strong>Paciente:</strong> <span id="recibo-paciente"></span></p>
                <p><strong>Operadora:</strong> <span id="recibo-operadora"></span></p>
                <p><strong>Valor:</strong> <span id="recibo-valor"></span></p>
                <p><strong>Data de Emissão:</strong> <span id="recibo-data"></span></p>
                <hr class="my-3">
                <p class="text-xs text-gray-500">Declaro que o serviço foi prestado e o valor acima será reembolsado conforme contrato.</p>
            </div>
            <div class="mt-5 flex justify-end space-x-2">
                <button onclick="fecharModal()" class="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 text-sm">Fechar</button>
                <button onclick="imprimirRecibo()" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm">Imprimir</button>
            </div>
        </div>
    </div>
</body>
</html>
```